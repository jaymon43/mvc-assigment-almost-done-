/**
	File name: Mctest.java
	Short description:
	IST 242 Assignment:
	@author Jared Furline
	@version 1.01 ?/??/????
*/ 
package Mctest;

/**
 *
 * @author jfurl
 */
public class Mctest {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
       Model model = new model();
        FairenheitGui FairenheitGui = new FairenheitGui();
    }

    private static class model extends Model {

        public model() {
        }
    }

    private static class FairenheitGui {

        public FairenheitGui() {
        }
    }
}

   